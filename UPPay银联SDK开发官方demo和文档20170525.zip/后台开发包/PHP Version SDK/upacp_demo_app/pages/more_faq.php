<h4>更多问题请使用open网站查找...</h4>
<p class="faq">
带7位应答码的错误请在 open网站-技术集成-应答码<a  href="https://open.unionpay.com/ajweb/help/respCode/respCodeList" target="_blank"> https://open.unionpay.com/ajweb/help/respCode/respCodeList</a>中搜索解决方法
</p>
<p class="faq">
 其他问题请在 open网站-帮助中心-FAQ<a href="https://open.unionpay.com/ajweb/help/faq/list" target="_blank"> https://open.unionpay.com/ajweb/help/faq/list</a>中搜索解决方法
</p>
